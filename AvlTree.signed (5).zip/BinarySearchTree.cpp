#include <iostream>
#include <string>
#include "BinarySearchTree.h"

using namespace std;

BinarySearchTree::BinarySearchTree() : root(nullptr)
{
}

BinarySearchTree::~BinarySearchTree()
{
    clear();
}

BinaryNode *BinarySearchTree::getRoot() const { return root; }

int BinarySearchTree::height() const { return height(root); }

int BinarySearchTree::height(const BinaryNode *ptr) const
{
    /***** Complete this function. *****/
    int h;
    int height_left,height_right;
    if (ptr == nullptr)  h = -1;
    else{
       height_left = height(ptr->left);
       height_right = height(ptr->right);
       h = 1 + (height_left>height_right ? height_left:height_right);
    }
    return h;
}

long BinarySearchTree::findMin() const throw(string)
{
    if (isEmpty()) throw(string("Empty tree"));
    return findMin(root)->data;
}

BinaryNode *BinarySearchTree::findMin(BinaryNode *ptr) const
{
    /***** Complete this function. *****/
    if(ptr!= nullptr){
       while(ptr->left != nullptr) ptr = ptr->left;
    }
    return ptr;
}

long BinarySearchTree::findMax() const throw(string)
{
    if (isEmpty()) throw(string("Empty tree"));
    return findMax(root)->data;
}

BinaryNode *BinarySearchTree::findMax(BinaryNode *ptr) const
{
    /***** Complete this function. *****/
    if(ptr!= nullptr){
       while(ptr->right != nullptr) ptr = ptr->right;
    }
    return ptr;
}

void BinarySearchTree::clear()
{
    clear(root);
}

void BinarySearchTree::clear(BinaryNode* &ptr)
{
    /***** Complete this function. *****/
    clear(ptr->left);
    clear(ptr->right);
    
    ptr = nullptr;
}

bool BinarySearchTree::isEmpty() const
{
    return root == nullptr;
}

bool BinarySearchTree::contains(const long data) const
{
    return contains(data, root);
}

bool BinarySearchTree::contains(const long data, BinaryNode *ptr) const
{
    /***** Complete this function. *****/
    while(ptr != nullptr){
       if (ptr->data == data) return true;
       if(data < ptr->data){
          ptr = ptr->left;
       }
       else{
          ptr = ptr->right;
       }
    }
    return false;
}

void BinarySearchTree::insert(const long data)
{
    insert(data, root);
}

void BinarySearchTree::insert(const long data, BinaryNode* &ptr)
{
//    cout << "=== Insert called on "
//         << (ptr != nullptr ? to_string(ptr->data) : "null")
//         << endl;

    /***** Complete this function. *****/
     
     if (ptr == nullptr){
       ptr = new BinaryNode(data);
    }
    else{
       if (data < ptr->data){
          insert(data,ptr->left);
       }
       else{
          insert(data, ptr->right);
       }
    }
   
}

void BinarySearchTree::remove(const long data)
{
    remove(data, root);
}

void BinarySearchTree::remove(const long data, BinaryNode* &ptr)
{
//    cout << "=== Remove called on "
//         << (ptr != nullptr ? to_string(ptr->data) : "null")
//         << endl;

    /***** Complete this function. *****/
    if (ptr == nullptr) return;

    if (data < ptr->data)
    {
        remove(data, ptr->left);
    }
    else if (data > ptr->data)
    {
        remove(data, ptr->right);
    }
    else if (   (ptr->left  != nullptr)
             && (ptr->right != nullptr))
    {
        ptr->data = findMin(ptr->right)->data;
        remove(ptr->data, ptr->right);
    }
    else
    {
        if(ptr->left == nullptr && ptr-> right == nullptr)  ptr = nullptr;
        else if(ptr->left != nullptr && ptr->right == nullptr) {
           ptr = ptr->left;
        }
        else if (ptr->right != nullptr && ptr->left == nullptr){
           ptr = ptr->right;
        } 
    }

    
}
