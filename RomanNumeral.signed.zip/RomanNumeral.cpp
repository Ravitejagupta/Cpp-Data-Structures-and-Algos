#include<string>
#include <iostream>
#include <typeinfo>
#include "RomanNumeral.h"
using namespace std;

RomanNumeral::RomanNumeral() : roman(""), decimal(0)
{
}

/***** Complete this class implementation. *****/
int RomanNumeral::get_decimal(){
   return decimal;}
   
string RomanNumeral::get_roman(){
   return roman;}
   

istream& operator >>(istream& instream,RomanNumeral &roman_a){
   instream>>roman_a.roman;
   roman_a.decimal = roman_a.to_decimal(roman_a.roman);
   return instream;}
   
ostream& operator <<(ostream& outs,RomanNumeral &roman_a){
   outs<<"["<<roman_a.get_decimal()<<":"<<roman_a.to_roman(roman_a.get_decimal())<<"]";
   return outs;
}

RomanNumeral operator+(RomanNumeral roman_a, RomanNumeral roman_b){
   int result;
   RomanNumeral roman;
   result=roman_a.get_decimal()+roman_b.get_decimal();
   roman=RomanNumeral(result);
   return roman;
}
RomanNumeral operator-(RomanNumeral roman_a, RomanNumeral roman_b){
   RomanNumeral roman;
   int result;
   result=roman_a.get_decimal()-roman_b.get_decimal();
   roman=RomanNumeral(result);
   return roman;
}

RomanNumeral operator /( RomanNumeral roman_a, RomanNumeral roman_b){
   int result;
   RomanNumeral roman;
   result=roman_a.get_decimal()/roman_b.get_decimal();
   roman=RomanNumeral(result);
   return roman;
}

RomanNumeral operator *( RomanNumeral roman_a, RomanNumeral roman_b){
   int result;
   RomanNumeral roman;
   result=roman_a.get_decimal()*roman_b.get_decimal();
   roman=RomanNumeral(result);
   return roman;
}

bool operator ==(RomanNumeral roman_a,RomanNumeral roman_b){
    return (roman_a.get_roman()==roman_b.get_roman());
    
}

RomanNumeral::RomanNumeral(string roman_a) : roman(roman_a)
{
   decimal = to_decimal(roman_a);
}
RomanNumeral::RomanNumeral(int roman_a) : decimal(roman_a)
{
   roman = to_roman(roman_a);
}
string RomanNumeral::to_roman(int dec){
 string rom = "";
 while(dec>0){
     if (dec>=1000){
       rom+="M";
       dec = dec-1000;}
    else if (dec > 899 && dec<1000){
       rom += "CM";
       dec = dec-900;}
    else if(dec >=500 && dec <900){
       rom+="D";
       dec = dec-500;}
    else if(dec >399 && dec <500){
       rom="CD";
       dec = dec-400;}
    else if(dec >=100 && dec < 400){
       rom+="C";
       dec = dec-100;}
    else if(dec > 89 && dec<100){
       rom+="XC";
       dec = dec-90;}
    else if(dec >=50 && dec <90){
       rom+="L";
       dec = dec-50;}
    else if(dec >39 && dec <50){
       rom+="XL";
       dec = dec-40;}
    else if(dec >=10 && dec <40){
       rom+="X";
       dec = dec-10;}
    else if(dec == 9){
       rom+="IX";
       dec = dec-9;}
    else if(dec >=5 && dec <9){
       rom+="V";
       dec = dec-5;}
    else if(dec == 4){
       rom+="IV";
       dec = dec-4;}
    else if(dec >0 && dec<4){
       rom+="I";
       dec = dec-1;}
 }
    return rom;


}
int RomanNumeral::to_decimal(string roman){
   int decimal=0;
   
   int counter = 0;
   while(counter<roman.length()-1){
      if(roman[counter]=='M'){
         decimal=decimal+1000;}
      else if(roman[counter]=='D' && roman_value(roman[counter+1]) >500){
         decimal=decimal-500;}
      else if(roman[counter]=='D' && roman_value(roman[counter+1]) <500){
         decimal=decimal+500;}
      else if(roman[counter]=='C' && roman_value(roman[counter+1]) >100){
         decimal=decimal-100;}
      else if(roman[counter]=='C' && roman_value(roman[counter+1])<=100){
         decimal=decimal+100;}
      else if(roman[counter]=='L' && roman_value(roman[counter+1]) >50){
         decimal=decimal-50;}
      else if(roman[counter]=='L' && roman_value(roman[counter+1]) <50){
         decimal=decimal+50;}
      else if(roman[counter]=='X' && roman_value(roman[counter+1]) >10){
         decimal=decimal-10;}
      else if(roman[counter]=='X' && roman_value(roman[counter+1]) <=10){
         decimal=decimal+10;}
      else if(roman[counter]=='V' && roman_value(roman[counter+1]) <5){
         decimal=decimal+5;}
      else if(roman[counter]=='I'){
         if(roman_value(roman[counter+1]) >1){
         decimal=decimal-1;
         }
         else decimal=decimal+1;}
      counter++;
    }
    int final_value = roman_value(roman[roman.length()-1]);
    decimal = decimal + final_value;
    return decimal;
}

int RomanNumeral::roman_value(char roman_digit){
      if(roman_digit == 'M') return 1000;
      else if(roman_digit == 'D') return 500;
      else if(roman_digit == 'C') return 100;
      else if(roman_digit == 'L') return 50;
      else if(roman_digit == 'X') return 10;
      else if(roman_digit == 'V') return 5;
      else if(roman_digit == 'I') return 1;
}