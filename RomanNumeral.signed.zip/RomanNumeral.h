#ifndef ROMANNUMERAL_H_
#define ROMANNUMERAL_H_
#include <string>
using namespace std;

class RomanNumeral
{
public:
    /**
     * Default constructor.
     */
    RomanNumeral();
    
    /***** Complete this class declaration. *****/


public:

   RomanNumeral(int r1);
   RomanNumeral(string r1);
   string get_roman();
   int get_decimal();
friend istream& operator >>(istream &instream,RomanNumeral& roman);
friend ostream& operator <<(ostream &outs,RomanNumeral& roman);

friend RomanNumeral operator+(const RomanNumeral roman_a, const RomanNumeral roman_b);
friend RomanNumeral operator-(const RomanNumeral roman_a, const RomanNumeral roman_b);
friend RomanNumeral operator*(const RomanNumeral roman_a, const RomanNumeral roman_b);
friend RomanNumeral operator/(const RomanNumeral roman_a, const RomanNumeral roman_b);
friend bool operator==(const RomanNumeral roman_a,const RomanNumeral roman_b);

//friend bool operator!=(const RomanNumeral r1,const RomanNumeral r2);


private:
   string to_roman(int r2);
   int to_decimal(string r1);
   int roman_value(char Roman_digit);
   string roman;
   int decimal;

};

#endif /* ROMANNUMERAL_H_ */