#include <iostream>
#include <vector>

using namespace std;

const int MAX_START = 50;   // maximum starting number


/***** Complete this program. *****/

void do_snake(const int n, const int start);
bool is_prime(int n);

/**
 * The main: Generate and print prime spirals of various sizes.
 */
int main()
{
    do_snake(5, 1);
    do_snake(25, 11);
    do_snake(35, 0);
    do_snake(50, 31);
    do_snake(101, 41);
}


void do_snake(const int n, const int start){
   
   cout<<"Diagonal Matrix of Size "<<n<<" starting at "<<start<<endl;
   if (n%2 == 0) {
      cout<<"***** Error: Size "<<n<<" must be odd."<<endl;
   }
   else if(start > MAX_START || start < 1){
      cout<<"***** Error: Starting value 0 < 1 or > 50"<<endl;
   }
   else{
   vector<vector<int>>arr; //Vector Declaration.
   
   arr.resize(n);
   for (int i = 0; i < n; i++){
    arr[i].resize(n);
   }
   
   string direction = "right";
   int num = start;
   
   for (int i=0;i<n;i++){
      if (direction == "right"){
         for (int j=0;j<n;j++){
            arr[i][j] = num;
            num++;
         }
         direction = "left";
      }
      else if (direction == "left"){
         for (int j=n-1;j>0;j--){
            arr[i][j] = num;
            num++;
         }
         direction = "right";
      } 
   }
   
   cout<<endl;
   for (int i=0;i<n;i++){
      for (int j =0;j<n;j++){
         if(is_prime(arr[i][j])) cout<<"#";
         else cout<<".";
         // cout<<arr[i][j]<<" ";
      }
      cout<<endl;
   }
   }
      cout<<endl;
}

bool is_prime(int n){
   if (n==1) return false;
   if (n==2) return true;
   for (int i=2; i< n*0.5; i++){
      if (n%i == 0) return false;
   }
   return true;
}