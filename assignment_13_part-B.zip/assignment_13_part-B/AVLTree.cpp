#include <iostream>
#include <chrono>
#include <ctime>
#include <string>
#include "AvlTree.h"

using namespace std;
using namespace std::chrono;

//long BinarySearchTree::elapsed_time = 0;
//long BinarySearchTree::probe_count=0;
//long BinarySearchTree::compare_count=0;
//long BinarySearchTree::search_elapsed_time = 0;
//long BinarySearchTree::search_probe_count=0;
//long BinarySearchTree::search_compare_count=0;

long AvlTree::AVLelapsed_time = 0;
long AvlTree::AVLprobe_count = 0;
long AvlTree::AVLcompare_count = 0;

long AvlTree::AVLsearch_elapsed_time = 0;
long AvlTree::AVLsearch_probe_count = 0;
long AvlTree::AVLsearch_compare_count = 0;


AvlTree::AvlTree()
    : BinarySearchTree()
{
}

AvlTree::~AvlTree()
{
}

int AvlTree::height(const BinaryNode *ptr) const
{
    return ptr == nullptr ? -1 : ptr->height;
}

void AvlTree::insert(const long data, BinaryNode* &ptr)
{
    steady_clock::time_point t1 = steady_clock::now();
    BinarySearchTree::insert(data, ptr);
    rebalance(ptr);
    steady_clock::time_point t2 = steady_clock::now();
    long t = duration_cast<milliseconds>(t2-t1).count();
    AVLelapsed_time += t;
}
long AvlTree::get_AVLelapsed_time() { return AVLelapsed_time;}
long AvlTree::get_AVLProbe_count(){return AVLprobe_count;}
long AvlTree::get_AVLCompare_count(){return AVLcompare_count;}

long AvlTree::get_AVL_search_probe_count(){return AVLsearch_probe_count;}
long AvlTree::get_AVL_search_elapsed_time(){return AVLsearch_elapsed_time;}
long AvlTree::get_AVL_search_compare_count(){return AVLsearch_compare_count;}

void AvlTree::reset_AVLProbe_count(){AVLprobe_count = 0;}
void AvlTree::reset_AVLelapsed_time(){AVLelapsed_time = 0;}
void AvlTree::reset_AVLCompare_count(){AVLcompare_count = 0;}

void AvlTree::reset_AVL_search_probe_count(){AVLsearch_probe_count = 0;}
void AvlTree::reset_AVL_search_elapsed_time() {AVLsearch_elapsed_time = 0;}
void AvlTree::reset_AVL_search_compare_count(){AVLsearch_compare_count=0;}
void AvlTree::remove(const long data, BinaryNode* &ptr)
{
    steady_clock::time_point t1 = steady_clock::now();
    BinarySearchTree::remove(data, ptr);
    rebalance(ptr);
    steady_clock::time_point t2 = steady_clock::now();
    long t = duration_cast<milliseconds>(t2-t1).count();
    AVLsearch_elapsed_time += t;
}

BinaryNode *AvlTree::rebalance(BinaryNode* &ptr)
{
    
    if (ptr == nullptr) 
    {
        AVLprobe_count++;
        AVLsearch_probe_count++;
        return ptr;
    }
    
    else if (height(ptr->left) - height(ptr->right) >1)
        {
        AVLprobe_count++;
        AVLcompare_count++;
        AVLsearch_probe_count++;
        AVLsearch_compare_count++;
            if (height(ptr->left->left) >= height(ptr->left->right))
            {
                AVLprobe_count++;
                AVLcompare_count++;
                AVLsearch_probe_count++;
                AVLsearch_compare_count++;
                ptr = singleRightRotation(ptr);
//                cout << "    --- Single right rotation at node "
//                     << ptr->data << endl;
            }
            else
            {
                AVLprobe_count++;
                AVLcompare_count++;
                AVLsearch_probe_count++;
                AVLsearch_compare_count++;
                ptr = doubleLeftRightRotation(ptr);
//                cout << "    --- Double left-right rotation at node "
//                     << ptr->data << endl;
            }
        }
    // Right side too high.
        else if (height(ptr->right) - height(ptr->left) > 1)
        {
            AVLsearch_probe_count++;
            AVLsearch_compare_count++;
            if (height(ptr->right->right) >= height(ptr->right->left))       
            {
                AVLsearch_probe_count++;
                AVLsearch_compare_count++;
                ptr = singleLeftRotation(ptr);
//                cout << "    --- Single left rotation at node "
//                     << ptr->data << endl;
            }
            else
            {
                AVLsearch_probe_count++;
                AVLsearch_compare_count++;
                ptr = doubleRightLeftRotation(ptr);
//                cout << "    --- Double right-left rotation at node "
//                     << ptr->data << endl;
            }
        }
  //  }
    
    ptr->height = (max(height(ptr->left), height(ptr->right)) + 1);

    if (checkBalance(ptr) < 0)
    {
        //cout << endl << "* Tree unbalanced!" << endl;
    }

    return ptr;
}


BinaryNode *AvlTree::singleRightRotation(BinaryNode *k2)
{
    BinaryNode *node = k2->left;
    BinaryNode *node2 = node->right;    
    node->right = k2;
    k2->left = node2; 
    k2->height = max(height(k2->left), height(k2->right))+1;
    node->height = max(height(node->left), height(node->right))+1;

    return node;
}

BinaryNode *AvlTree::doubleLeftRightRotation(BinaryNode *k3)
{
    /* Complete this function. */
    k3->left =  singleLeftRotation(k3->left);
    return singleRightRotation(k3);
}

BinaryNode *AvlTree::doubleRightLeftRotation(BinaryNode *k1)
{
    /* Complete this function. */
     k1->right = singleRightRotation(k1->right);
    return singleLeftRotation(k1);
}

BinaryNode *AvlTree::singleLeftRotation(BinaryNode *k1)
{   
   
    BinaryNode *node = k1->right;
    BinaryNode *node2 = node->left;    
    node->left = k1;
    k1->right = node2;
    k1->height = max(height(k1->left), height(k1->right))+1;
    node->height = max(height(node->left), height(node->right))+1;
 
    return node;
    
}

int AvlTree::checkBalance(BinaryNode *ptr)
{
    if (ptr == nullptr) return -1;

    int leftHeight  = checkBalance(ptr->left);
    int rightHeight = checkBalance(ptr->right);

    if ((abs(height(ptr->left) - height(ptr->right)) > 1)
        || (height(ptr->left)  != leftHeight)
        || (height(ptr->right) != rightHeight))
    {
        return -2;       // unbalanced
    }

    return height(ptr);  // balanced
}