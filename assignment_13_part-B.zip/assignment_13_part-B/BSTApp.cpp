/**
 * Test the binary search tree and AVL tree implementations.
 * The AVL tree is derived from the binary search tree.
 *
 * Create a tree of height 5 and then repeatedly
 * delete the root. The AVL tree should remain balanced
 * after each node insertion and deletion.
 *
 * Author: Ron Mak
 *         Department of Computer Engineering
 *         San Jose State University
 */
#include <iostream>
#include <vector>
#include<time.h> // for clock
#include<math.h> // for fmod
#include<cstdlib> //for system
#include <stdio.h> //for delay
#include <chrono>
#include <unistd.h>

#include "BinarySearchTree.h"
#include "AvlTree.h"
#include "BinaryTreeChecker.h"
#include "BinaryTreePrinter.h"

using namespace std;
using namespace std::chrono;
const bool DO_DUMP = false;

enum class TreeType
{
    BST, AVL
};

/**
 * Print the tree type.
 */
ostream& operator <<(ostream& out, const TreeType& type);

/**
 * Run the test with a binary search tree.
 */
void testBST(long size);

/**
 * Run the test with an AVL tree.
 */
void testAVL(long size);

/**
 * Build a binary search tree containing unique random integer data items.
 * @param tree the tree to build.
 * @param checker the binary tree checker to use.
 * @param printer the binary tree printer to use.
 * @param type the type of tree (BST or AVL).
 */
void build_tree(BinarySearchTree& tree,
                BinaryTreeChecker& checker,
                TreeType type, long size);

/**
 * Dismantle a binary tree.
 * @param tree the tree to test.
 * @param checker the binary tree checker to use.
 * @param printer the binary tree printer to use.
 */
void dismantle_tree(BinarySearchTree& tree,
                    BinaryTreeChecker& checker);

/**
 * Main.
 */
int main( )
{
    //auto start = chrono::steady_clock::now();
     cout << "* BINARY SEARCH TREE *" << endl;
    for(long i=5000;i<=50000;i++){
        BinarySearchTree().reset_elapsed_time();    
        BinarySearchTree().search_reset_elapsed_time();
        BinarySearchTree().reset_compare_count();
        BinarySearchTree().reset_probe_count(); 
        BinarySearchTree().search_reset_compare_count();
        BinarySearchTree().search_reset_probe_count();
        testBST(i);      
        
         cout<<"************************************************************************************"<<endl;
        cout<<" BST Stats for "<< i << " values : Insertion    ;   search "<<endl;
        cout<<"************************************************************************************"<<endl;
        cout<<" Elapsed Time  : "<< BinarySearchTree().get_elapsed_time()<<"        ; "<<BinarySearchTree().search_get_elapsed_time()<<endl;
        cout<<" Probe Count   : "<< BinarySearchTree().get_probe_count()<<"      ; "<<BinarySearchTree().search_get_probe_count()<<endl;
        cout<<" Compare Count : "<< BinarySearchTree().get_compare_count()<<"     : "<<BinarySearchTree().search_get_compare_count()<<endl;

        BinarySearchTree().reset_elapsed_time();    
        BinarySearchTree().search_reset_elapsed_time();
        BinarySearchTree().search_reset_compare_count();
        BinarySearchTree().search_reset_probe_count();
        BinarySearchTree().reset_compare_count();
        BinarySearchTree().reset_probe_count(); 
         
        i+=4999;
    } 
     cout << "* AVLTREE *" << endl;
    for(long i=5000;i<=50000;i++){
        
//        long get_AVLelapsed_time();
//    long get_AVLProbe_count();
//    long get_AVLCompare_count();
//    
//    long get_AVL_search_probe_count();
//    long get_AVL_search_elapsed_time();
//    long get_AVL_search_compare_count();
//    
//    void reset_AVLProbe_count();
//    void reset_AVLelapsed_time();
//    void reset_AVLCompare_count();
//    
//    void reset_AVL_search_probe_count();
//    void reset_AVL_search_elapsed_time();
//    void reset_AVL_search_compare_count();
        
        AvlTree().reset_AVLelapsed_time();    
        AvlTree().reset_AVL_search_elapsed_time();
        AvlTree().reset_AVLCompare_count();
        AvlTree().reset_AVLProbe_count(); 
        AvlTree().reset_AVL_search_compare_count();
        AvlTree().reset_AVL_search_probe_count();
        testAVL(i);      
        
        cout<<"************************************************************************************"<<endl;
        cout<<" AVL Stats for "<< i << " values : Insertion    ;   Search "<<endl;
        cout<<"************************************************************************************"<<endl;
        cout<<" Elapsed Time  : "<< AvlTree().get_AVLelapsed_time()<<"        ; "<<AvlTree().get_AVL_search_elapsed_time()<<endl;
        cout<<" Probe Count   : "<< AvlTree().get_AVLProbe_count()<<"      ; "<<AvlTree().get_AVL_search_probe_count()<<endl;
        cout<<" Compare Count : "<< AvlTree().get_AVLCompare_count()<<"     : "<<AvlTree().get_AVL_search_compare_count()<<endl;
       
        
//        cout<<"************************************************************************************"<<endl;
//        cout<<" AVL Stats for "<< i << " values : elapsed_time , probe_count , compare_count "<<endl;
//        cout<<"************************************************************************************"<<endl;
//        cout<<" insertion       : "<< BinarySearchTree().get_elapsed_time()<<" , "<<BinarySearchTree().get_probe_count()<<" , "<<BinarySearchTree().get_compare_count()<<endl;
//        cout<<" search        : "<< BinarySearchTree().search_get_elapsed_time()<<" , "<<BinarySearchTree().search_get_probe_count()<<" , "<<BinarySearchTree().search_get_compare_count()<<endl;

        AvlTree().reset_AVLelapsed_time();    
        AvlTree().reset_AVL_search_elapsed_time();
        AvlTree().reset_AVLCompare_count();
        AvlTree().reset_AVLProbe_count(); 
        AvlTree().reset_AVL_search_compare_count();
        AvlTree().reset_AVL_search_probe_count(); 
        i+=4999;
    } 
}

ostream& operator <<(ostream& out, const TreeType& type)
{
    out << (type == TreeType::BST ? "BST" : "AVL");
    return out;
}

void testBST(long size)
{
//    cout << endl;
//    cout << "**********************" << endl;
//    cout << "* BINARY SEARCH TREE *" << endl;
//    cout << "**********************" << endl;

    BinarySearchTree  tree;
    BinaryTreeChecker checker(tree);
    //BinaryTreePrinter printer(tree); 

    build_tree(tree, checker, TreeType::BST,size);
   dismantle_tree(tree, checker);
}

void testAVL(long size)
{
//    cout << endl;
//    cout << "************" << endl;
//    cout << "* AVL TREE *" << endl;
//    cout << "************" << endl;

    AvlTree tree;
    BinaryTreeChecker checker(tree);
    //BinaryTreePrinter printer(tree);

    build_tree(tree, checker, TreeType::AVL, size);
    dismantle_tree(tree, checker);
}

static const long VALUES[] = {
    62,71,29,88,11,41,21,66,57,27,39,40,77,20,51,49,82,37,
    94,63,76,91,70,64,60,90,12,80,23,10,52,35,96,75,28
};

void build_tree(BinarySearchTree& tree,
                BinaryTreeChecker& checker,
                TreeType type, long size)
{
//    time_t t1,t2;
//    time(&t1);
    long c = 0;
    
    while(c<size)
    {
        //cout << endl << "Inserting node " << n << ":" << endl;
        long r=rand()%size;
        tree.insert(r);  // insert into tree
        checker.add(r);  // store with the tree checker
        c++;
        //cout << endl;
        //printer.print();
    }
//    time(&t2);
//    double dif = difftime (t2,t1);
//    cout << endl;
//    cout << "*****" << endl;
//    cout << "***** COMPLETED " << type << " TREE:" << endl;
//    cout << "*****" << endl << endl;
//    cout<<dif*1000000<<endl;
    //printer.print();
}

void dismantle_tree(BinarySearchTree& tree,
                    BinaryTreeChecker& checker)
{
    TreeStatus status = TreeStatus::NO_ERROR;

    // Delete the root node each time through the loop.
    // Print the tree after each deletion.
    while (!tree.isEmpty())
    {
        BinaryNode *root = tree.getRoot();
        long data = root->data;
        //cout << endl << "Deleting root node " << data << ":" << endl;

        tree.remove(data);
        checker.remove(data);

       // cout << endl;
       // printer.print();

        status = checker.check(DO_DUMP);
        if (status != TreeStatus::NO_ERROR) break;
    }

    // What was the status?
   // cout << status << endl;
}
